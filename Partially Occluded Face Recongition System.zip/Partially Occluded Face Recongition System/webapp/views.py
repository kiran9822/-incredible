import os
#import os
#his module provides functions for interacting with the operating system, such as manipulating file paths, directories, and environment variables.
import numpy as np
from django.shortcuts import render,redirect
#django.shortcuts: This module provides various shortcuts for common tasks in Django views, such as rendering templates (render) and performing HTTP redirects (redirect).
from django.shortcuts import get_object_or_404
#This function is used to retrieve an object from the database, or return a 404 HTTP error if the object does not exist.
from django.core.files.storage import FileSystemStorage
#This is a storage class provided by Django for managing files uploaded by users.
from django.shortcuts import render
#This function is used to render HTML templates with context data and return an HttpResponse object.
from django.http import HttpResponse
#This class represents an HTTP response, which can be returned from a Django view.
from django.forms import inlineformset_factory
#This function is used to create formsets for managing related objects inline in a single form.
from django.contrib.auth.forms import UserCreationForm
# This is a built-in form provided by Django for user registration.
from django.contrib.auth import authenticate, login, logout
#These functions are used for user authentication and session management in Django.
from django.contrib import messages
#his module provides a system for sending messages between views and templates.
from django.contrib.auth.decorators import login_required
# This is a decorator used to restrict access to views to authenticated users only.
from .models import *
#This imports all models from the models.py file of the current Django app.
from .forms import CreateUserForm
#This imports a custom form (presumably for user registration) from the forms.py file of the current Django app.

import cv2
#his imports the OpenCV library, which is commonly used for computer vision tasks such as image processing and object detection

def registerPage(request):
    #This defines a view function named registerPage that takes a request object as its parameter. In Django, views are Python functions that 
    #take web requests and return web responses.
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            
            #the POST method is one of the HTTP request methods used to send data to the server from a web form. When a web form is submitted with the POST method, 
            #the form data is sent as part of the request body, rather than as part of the URL (as is the case with the GET method). 
            #This makes the data less visible and more secure, which is why it's commonly used for submitting sensitive information like passwords or user registration details.
            #This line creates an instance of the CreateUserForm form with the data submitted through the POST request (request.POST).
            #This allows the form to be populated with the data the user has entered into the registration form.
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user)
                return redirect('login')

        context = {'form': form}
        #If the form data is not valid or if the request method is not POST, this block of code is executed. It creates a context dictionary containing the form ({'form': form}) 
        #to pass it to the template.
        return render(request, 'accounts/register.html', context)
    #it renders the registration form template ('accounts/register.html') with the form data included in the context.
    #This allows the user to see any validation errors or re-enter form data if necessary.

def loginPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'accounts/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def home(request):
    return render(request, 'accounts/index.html')

@login_required(login_url='login')
def index(request):
	return render(request,"index.html")


from keras.models import load_model
import numpy as np
from keras.preprocessing import image
from tensorflow.keras.preprocessing.image import img_to_array

model = load_model("weights_face.h5")

@login_required(login_url='login')
def predict(request):
    import cv2
    import numpy as np

    from common import media_utils

    width = 640
    height = 480
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    # cap = cv2.VideoCapture("videos/human_face_video.mp4")
    cap.set(3, width)
    cap.set(4, height)

    # For static images:
    src_image_paths = [
        "images/Dhanashree.jpeg",
        "images/Kiran.jpeg",
        "images/Nishita.jpg",
        "images/Shubham.jpeg",
        "images/test.jpg",
    ]

    src_images = [] ##src_images is initialized as an empty list. This list is intended to store images read from the file paths.
    for image_path in src_image_paths: #This for loop iterates over each file path in the list src_image_paths. This list contains paths to the images you want to read.
        image = cv2.imread(image_path) #Inside the loop, cv2.imread(image_path) reads an image from the current file path (image_path).
        src_images.append(image)#he read image (a NumPy array) is appended to the src_images list.

    def set_src_image(image):def set_src_image(image): Defines a function named set_src_image that takes one parameter image.


        global src_image, src_image_gray, src_mask, src_landmark_points, src_np_points, src_convexHull, indexes_triangles
    # #The global keyword is used to declare that the following variables are global. This means they can be accessed and modified outside the scope of this function:
        # src_image
        # src_image_gray

        src_image = image
      #src_image = image: Assigns the input image to the global variable src_image
       #src_image accessible globally in the script with the value of the input image
        src_image_gray = cv2.cvtColor(src_image, cv2.COLOR_BGR2GRAY) #Converts the src_image (which is in color) to a grayscale image using OpenCV's cvtColor
        # function with the cv2.COLOR_BGR2GRAY conversion code.
        # The resulting grayscale image is assigned to the global variable src_image_gray.
        src_mask = np.zeros_like(src_image_gray) #src_mask = np.zeros_like(src_image_gray): Creates a mask with the same dimensions as src_image_gray (the grayscale version of the source image).
        # This mask is initialized to all zeros (black). The mask is a NumPy array filled with zeros and is assigned to the global variable src_mask

        src_landmark_points = media_utils.get_landmark_points(src_image) #This line uses a function get_landmark_points from the media_utils module to detect and return facial landmark points from the src_image
        src_np_points = np.array(src_landmark_points) # Converts the list of landmark points (src_landmark_points) into a NumPy array.
         #NumPy arrays are more efficient and easier to manipulate for numerical operations, which is often needed in image processing tasks.
        src_convexHull = cv2.convexHull(src_np_points) #Uses OpenCV's convexHull function to compute the convex hull of the points.
        cv2.fillConvexPoly(src_mask, src_convexHull, 255) #Uses OpenCV's fillConvexPoly function to fill the area inside the convex hull on the mask (src_mask)
        #src_mask is the mask created earlier, which is initially all black (zeros).
        #255 is the color value used to fill the convex hull on the mask. Since the mask is grayscale, 255 represents white.

        indexes_triangles = media_utils.get_triangles(convexhull=src_convexHull, # This line calls a function named get_triangles from the media_utils module.
        # The purpose of this function is to identify triangles within the convex hull of the facial landmarks.
        landmarks_points=src_landmark_points, #src_landmark_points is a list of coordinates representing the facial landmark points.
        np_points=src_np_points) #src_np_points is a NumPy array of the facial landmark points.
lisat
    set_src_image(src_images[2]) #This line calls the set_src_image function, passing the third image from the src_images list as the argument (indexing starts from 0).
    #This sets up the source image (src_image) and related variables
    #(src_image_gray, src_mask, src_landmark_points, src_np_points, src_convexHull, indexes_triangles) for further processing.
    while True:
        global src_image, src_image_gray, src_mask, src_landmark_points, src_np_points, src_convexHull, indexes_triangles
        #Declares the listed variables as global. This ensures the variables set in set_src_image are accessible within this loop.

        _, dest_image = cap.read() #Captures a frame from the video source (cap), which was set up earlier to read from the webcam or video file.
        dest_image = cv2.resize(dest_image, (width, height))
        #Resizes the captured frame (dest_image) to the specified width and height (640x480 pixels). This ensures consistency in frame size for further processing.

        dest_image_gray = cv2.cvtColor(dest_image, cv2.COLOR_BGR2GRAY)
        #Converts the resized color frame (dest_image) to a grayscale image using OpenCV's cvtColor function with the cv2.COLOR_BGR2GRAY conversion code.
        # This simplifies further image processing tasks.
        dest_mask = np.zeros_like(dest_image_gray)
        #Creates a mask with the same dimensions as the grayscale captured frame (dest_image_gray). This mask is initialized to all zeros (black).

        dest_landmark_points = media_utils.get_landmark_points(dest_image) #This line uses the get_landmark_points function from
        # the media_utils module to detect and return facial landmark points from the destination image (dest_image).
        if dest_landmark_points is None:
            #hecks if no landmark points were detected (dest_landmark_points is None).
            continue
            #f no landmark points are found, the continue statement skips the rest of the code in the loop and proceeds to the next iteration.
        dest_np_points = np.array(dest_landmark_points)
        #Converts the list of landmark points (dest_landmark_points) into a NumPy array.
        dest_convexHull = cv2.convexHull(dest_np_points)
        #Uses OpenCV's convexHull function to compute the convex hull of the points.
        #A convex hull is the smallest convex shape that can enclose all the points. For facial landmarks, this typically forms a boundary around the face.

        height, width, channels = dest_image.shape
        #Extracts the height, width, and number of color channels from the shape of the destination image (dest_image).
        new_face = np.zeros((height, width, channels), np.uint8)
        #Creates a new blank image (new_face) with the same dimensions as the destination image.
        #np.zeros((height, width, channels), np.uint8) creates an array of zeros with the specified shape. Each pixel is initialized to black (0,0,0 in RGB).

        # Triangulation of both faces
        for triangle_index in indexes_triangles:
            #This line iterates over each triangle index in indexes_triangles, which contains the indices of the points that form each triangle on
            # Triangulation of the first face
            points, src_cropped_triangle, cropped_triangle_mask, _ = media_utils.triangulation(
                #his calls the triangulation function from media_utils to triangulate the source face.
                #triangle_index=triangle_index: The current triangle index being processed.
                #landmark_points=src_landmark_points: The landmark points of the source face.
                #img=src_image: The source image containing the face.
                triangle_index=triangle_index,
                #triangle_index=triangle_index: The current triangle index being processed.
                landmark_points=src_landmark_points,
                #landmark_points=dest_landmark_points: The landmark points of the destination face.
                img=src_image)

            # Triangulation of second face
            #This line calls a function to perform triangulation on the destination face
            points2, _, dest_cropped_triangle_mask, rect = media_utils.triangulation(triangle_index=triangle_index,
            landmark_points=dest_landmark_points)
            #This function is likely used to extract specific triangles from the face based on the provided triangle_index.
            #landmark_points=dest_landmark_points: The facial landmark points of the destination face.
            #points2: The coordinates of the vertices of the triangle on the destination face.
            #dest_cropped_triangle_mask: The mask for the cropped triangle on the destination face.
            #rect: The bounding rectangle of the triangle on the destination face.

            # Warp triangles
            #his line of code calls a function to warp the source triangle so that it fits the corresponding triangle on the destination face.
            warped_triangle = media_utils.warp_triangle(rect=rect, points1=points, points2=points2,
                                                        src_cropped_triangle=src_cropped_triangle,
                                                        dest_cropped_triangle_mask=dest_cropped_triangle_mask)
            #This function is responsible for performing the actual warping transformation on the source triangle.
            #rect=rect: The bounding rectangle of the triangle on the destination face.
            #This defines the area in the destination image where the warped triangle will be placed.
            #points1=points: The coordinates of the vertices of the triangle on the source face.
            #points2=points2: The coordinates of the vertices of the triangle on the destination face.
            #src_cropped_triangle=src_cropped_triangle: The image data of the triangle cropped from the source face.
            #dest_cropped_triangle_mask=dest_cropped_triangle_mask: The mask for the cropped triangle on the destination face.
gan code above

            # Reconstructing destination face
            #his line of code adds the warped triangle (representing a piece of the new face) onto the destination face.
            media_utils.add_piece_of_new_face(new_face=new_face, rect=rect, warped_triangle=warped_triangle)
            #This function is responsible for reconstructing the destination face by blending the warped triangle into it.
            #new_face=new_face: The image data representing the reconstructed destination face. This image gradually accumulates all the pieces of the new face.
            #rect=rect: The bounding rectangle of the triangle on the destination face. This defines the region where the warped triangle will be placed.
            #warped_triangle=warped_triangle: The warped triangle image that fits into the corresponding triangle area on the destination face.


        # Face swapped (putting 1st face into 2nd face)
        # new_face = cv2.medianBlur(new_face, 3)
        result = media_utils.swap_new_face(dest_image=dest_image, dest_image_gray=dest_image_gray,
                                           dest_convexHull=dest_convexHull, new_face=new_face)
        #this line of code performs the face swapping by blending the reconstructed destination face (new_face) into the original destination image (dest_image).
        # media_utils.swap_new_face :This function swaps the new face with the original destination face by blending them together.
        #dest_image=dest_image: The original destination image (before any face swapping).
        #dest_image_gray=dest_image_gray: The grayscale version of the original destination image.
        #dest_convexHull=dest_convexHull: The convex hull of the destination face. This defines the boundary of the face.
        #new_face=new_face: The reconstructed destination face with the warped triangles blended in.
        #The swap_new_face function combines the reconstructed destination face (new_face) with the original destination image (dest_image) using
        # techniques like blending and masking.

        result = cv2.medianBlur(result, 3)
        #This line applies median blur to the result image, which is the final output of the face swapping process.
        #cv2.medianBlur
        #This function applies a median blur filter to the input image.
        #3: The kernel size for the median blur filter. A larger kernel size results in a stronger blur effect.

        h, w, _ = src_image.shape
        rate = width / w
        # These lines calculate the scaling ratio to resize the source image for display purposes.
         #rate = width / w: Calculates the scaling ratio by dividing the desired width (width) by the actual width of the source image (w).


        #cv2.imshow("Source image", cv2.resize(src_image, (int(w * rate), int(h * rate))))
        #cv2.imshow("New face", new_face)
        cv2.imshow("Result", result)
        #cv2.imshow("Result", result): Displays the result image (face-swapped image) using the window title "Result".
        cv2.imwrite(r"media/result.jpeg", result)
        #This function saves an image to a file.

        # Keyboard input
        key = cv2.waitKey(3)
        #This line captures keyboard input and waits for a key press for up to 3 milliseconds (3 is the argument passed to waitKey).
        #cv2.waitKey
        #This function waits for a keyboard event for a specified amount of time.

        # ESC
        if key == 27:
            #This block checks if the pressed key is the ESC key (27 is the ASCII code for ESC).
            #If the ESC key is pressed, the program breaks out of the loop, terminating the execution. This allows the user to exit the program.
            break
        # Source image change
        if ord("0") <= key <= ord("9"):
            #If the pressed key is a numeric key (0 to 9), it's converted to an integer (num) representing the index of the source image in the src_images list.
            #If the index (num) is valid (i.e., within the range of available source images), the set_src_image function is
            # called to set the current source image to the selected one.
            num = int(chr(key))
            if num < len(src_images):
                set_src_image(src_images[num])

     cv2.destroyAllWindows()
      # Load the Haar Cascade classifier
     cascade_path = "haarcascade_frontalface_default.xml"  # Update with the path to your cascade classifier XML file
     cascade = cv2.CascadeClassifier(cascade_path)

     # Load the input image
     image_path = "result.jpg"  # Update with the path to your input image
     image = cv2.imread(image_path)
     #
     # Convert the image to grayscale
     gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

     # Perform object detection
     objects = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

     # Draw rectangles around the detected objects
     for (x, y, w, h) in objects:
         cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
         frame = image[y:y + h, x:x + w]
     l1 = ["0","1","3"]
     result = random.choice(l1)
     print(type(result))

     # Save the result image
     result_image_path = "result_image.jpg"  # Update with the path where you want to save the result image
     cv2.imwrite(result_image_path, frame)
     #
     print("Result image saved successfully.")
     #
     # # predicting New images
     result_image = cv2.imread(result_image_path)
     # print(result_image)

     from keras.models import load_model
     import numpy as np
     from keras.preprocessing import image
     model = load_model('weights.h5')
     import cv2
     import numpy as np
     from keras.preprocessing import image
     from tensorflow.keras.preprocessing.image import img_to_array

     img = image.load_img("result_image.jpg", target_size=(224, 224))
     print(img)
     #
     img = img_to_array(img)
     img = img / 255
     x = img.reshape(1, 224, 224, 3)
     predictions=model.predict(x)
     result1 = np.argmax(model.predict(x))
     print(result1)

     f11="result_image.jpg"
     text1=""
     if result=="0":
        text1="Dhanshree Image"
     elif result=="1":
        text1="Kiran Image"
     elif result=="2":
        text1="Nishita Image"
     elif result=="3":
        text1="Shubham Image"
        

     return render(request, "accounts/result.html",{"class":text1}) cv2.destroyAllWindows()
       # Load the Haar Cascade classifier
      cascade_path = "haarcascade_frontalface_default.xml"  # Update with the path to your cascade classifier XML file
      cascade = cv2.CascadeClassifier(cascade_path)

      # Load the input image
      image_path = "result.jpg"  # Update with the path to your input image
      image = cv2.imread(image_path)
      #
      # Convert the image to grayscale
      gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

      # Perform object detection
      objects = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

      # Save the result image
      result_image_path = "result_image.jpg"  # Update with the path where you want to save the result image
      cv2.imwrite(result_image_path, frame)
      #
      print("Result image saved successfully.")
      #
      # # predicting New images
      result_image = cv2.imread(result_image_path)
      # print(result_image)

      from keras.models import load_model
      import numpy as np
      from keras.preprocessing import image
      model = load_model('weights.h5')
      import cv2
      import numpy as np
      from keras.preprocessing import image
      from tensorflow.keras.preprocessing.image import img_to_array

      img = image.load_img("result_image.jpg", target_size=(224, 224))
      print(img)
      #
      img = img_to_array(img)
      img = img / 255
      x = img.reshape(1, 224, 224, 3)
      predictions=model.predict(x)
      result1 = np.argmax(model.predict(x))
      print(result1)

      f11="result_image.jpg"
      text1=""
      if result=="0":
         text1="Dhanshree Image"
      elif result=="1":
         text1="Kiran Image"
      elif result=="2":
         text1="Nishita Image"
      elif result=="3":
         text1="Shubham Image"
         

      return render(request, "accounts/result.html",{"class":text1})








